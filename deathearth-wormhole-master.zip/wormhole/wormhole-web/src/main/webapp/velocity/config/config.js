define({
  "collectPush": {  // 进件装入
    "maxPushInCount": 8000,       // 进件装入最大件数
    "minPushInAmount": 1      // 进件装入最小金额
  }
})