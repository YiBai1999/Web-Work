package com.kaistart.gateway.support.proto;

/**
 * 抽象模型（bean）原型类
 *
 * @author 翁耀中 2016/12/7.
 */
public class ProtoBean { }
