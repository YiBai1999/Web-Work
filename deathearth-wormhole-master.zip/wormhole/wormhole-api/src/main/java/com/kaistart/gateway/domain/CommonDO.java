/*
 * Copyright 2016 kaistart.com All right reserved. This software is the
 * confidential and proprietary information of kaistart.com ("Confidential
 * Information"). You shall not disclose such Confidential Information and shall
 * use it only in accordance with the terms of the license agreement you entered
 * into with kaistart.com.
 */
package com.kaistart.gateway.domain;

import java.io.Serializable;

/**
 *
 * 
 * @author chenhailong
 * @date 2018年7月17日 下午6:53:14 
 */
public class CommonDO implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = -177352078786233922L;

}
